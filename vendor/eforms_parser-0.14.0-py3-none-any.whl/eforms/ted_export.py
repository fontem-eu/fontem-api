"""Parser for legacy TED (pre-eForms) XML — the ``<TED_EXPORT>`` schema.

eForms replaced the old TED S-series forms during 2023-2024. Notices
published before a buyer migrated (roughly 2023 to mid-2024) still
arrive as ``<TED_EXPORT>`` documents whose ``FORM_SECTION`` holds an
S-form (``F20_2014`` for contract modifications, ``F03_2014`` for
awards, …). The eForms extractors assume a ``<ContractAwardNotice>``
root with ``cbc:``/``cac:`` UBL elements and find nothing in these.

This module extracts the subset the pipeline consumes — buyer,
contractors, the (possibly modified) contract value, CPV, notice type —
from the legacy schema. It is deliberately narrow: modifications are
what the backfill needs, so the ``F20`` ``INFO_MODIFICATIONS`` value
block is first-class here.

Namespace-agnostic by design: legacy TED spans several schema versions
(R2.0.8 / R2.0.9 / …) whose namespace URIs differ, so every lookup
matches on ``local-name()`` rather than a fixed prefix map.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from lxml import etree

from .languages import to_iso639_1
from .models import Award, LegalIdentifier, Notice, Organization

# Legacy ``TD_DOCUMENT_TYPE/@CODE`` -> eForms-style notice-type slug.
# Only the codes the pipeline acts on are mapped; "K" (modification of a
# contract/concession) is the reason this parser exists. The rest are a
# defensive courtesy — the loader stamps the authoritative notice-type
# from the search response regardless.
_DOC_TYPE_TO_NOTICE_TYPE = {
    "K": "can-modif",     # Modification of a contract/concession
    "7": "can-standard",  # Contract award notice
    "9": "can-social",    # Contract award — social & other specific services
}


def looks_like_ted_export(root: etree._Element) -> bool:
    """True if ``root`` is a legacy ``<TED_EXPORT>`` document."""
    return etree.QName(root.tag).localname == "TED_EXPORT"


def _local(ctx, name: str):
    """Descendants of ``ctx`` whose local name is ``name`` (any namespace)."""
    if ctx is None:
        return []
    return ctx.xpath(".//*[local-name()=$n]", n=name)


def _first(ctx, name: str):
    hits = _local(ctx, name)
    return hits[0] if hits else None


def _text(el) -> str | None:
    if el is None:
        return None
    txt = "".join(el.itertext()).strip()
    return txt or None


def _num(text: str | None) -> float | None:
    if not text:
        return None
    try:
        return float(text)
    except (TypeError, ValueError):
        return None


def _int(text: str | None) -> int | None:
    if not text:
        return None
    try:
        return int(text.strip())
    except (TypeError, ValueError):
        return None


def _fmt_date(raw: str | None) -> str | None:
    """``20240115`` -> ``2024-01-15``; anything else passes through."""
    if raw and len(raw) == 8 and raw.isdigit():
        return f"{raw[:4]}-{raw[4:6]}-{raw[6:8]}"
    return raw


def _country(block, fallback: str | None) -> str | None:
    """Country of an address block: prefer ``ISO_COUNTRY``/``COUNTRY``
    ``@VALUE`` within the block, else the notice-level fallback."""
    for tag in ("ISO_COUNTRY", "COUNTRY"):
        el = _first(block, tag)
        if el is not None and el.get("VALUE"):
            return el.get("VALUE")
    return fallback


def _legal_id(block) -> LegalIdentifier | None:
    """Legacy contractor/buyer national registration id, when present."""
    val = _text(_first(block, "NATIONALID"))
    return LegalIdentifier(value=val, scheme_name="NATIONAL") if val else None


def _pick_form(root):
    """The single S-form to read. ``FORM_SECTION`` wraps one form per
    language; prefer ``CATEGORY="ORIGINAL"``, else the first, else the
    whole document (defensive — some exports inline the form)."""
    section = _first(root, "FORM_SECTION")
    if section is None:
        return root
    forms = list(section)
    for form in forms:
        if form.get("CATEGORY") == "ORIGINAL":
            return form
    return forms[0] if forms else root


@dataclass
class _Money:
    """An amount as published: the number, its currency and the text the
    number was parsed from (``raw`` keeps the decimal presence a float
    cannot)."""

    value: float | None = None
    currency: str | None = None
    raw: str | None = None


@dataclass
class _Totals:
    """The notice-level money of a legacy form: the (possibly modified)
    total, its currency, the text it was parsed from, and — on an F20 —
    the pre-modification total."""

    before: float | None = None
    after: float | None = None
    currency: str | None = None
    after_raw: str | None = None


def _title_language(form, coded) -> str | None:
    """ISO 639-1 language of the title read from ``form``.

    That form's ``LG`` is the language its title is written in, whichever
    form :func:`_pick_form` settled on; ``LG_ORIG`` covers an inlined form.
    None when there is no title or neither code is recognisable.
    """
    if _text(_first(form, "TITLE")) is None:
        return None
    return (to_iso639_1(form.get("LG"))
            or to_iso639_1(_text(_first(coded, "LG_ORIG"))))


def _modification_values(form) -> _Totals:
    """The before/after totals from an ``F20`` ``INFO_MODIFICATIONS`` block.

    Legacy modification notices self-contain the value change: the
    corruption signal is ``VAL_TOTAL_BEFORE`` -> ``VAL_TOTAL_AFTER``.
    ``VAL_TOTAL`` is a standalone total published when a notice carries
    only one figure; ``after`` falls back to it. ``after_raw`` is the
    verbatim text of whichever element ``after`` came from."""
    info = _first(form, "INFO_MODIFICATIONS")
    scope = _first(info, "VALUES") if info is not None else None
    if scope is None:
        scope = _first(form, "VALUES")

    def _one(tag):
        el = _first(scope, tag)
        txt = _text(el)
        return _num(txt), (el.get("CURRENCY") if el is not None else None), txt

    before, cur_b, _ = _one("VAL_TOTAL_BEFORE")
    after, cur_a, raw_a = _one("VAL_TOTAL_AFTER")
    total, cur_t, raw_t = _one("VAL_TOTAL")
    if after is None and total is not None:
        after, raw_a = total, raw_t
    return _Totals(
        before=before,
        after=after,
        currency=cur_a or cur_t or cur_b,
        after_raw=raw_a,
    )


def _reference_number(root) -> str | None:
    """S-form II.1.1 ``<REFERENCE_NUMBER>``: the file reference the authority
    gave the procedure. The closest thing a pre-eForms notice has to a
    procedure id; kept as ``legacy_procedure_id`` for querying, never used
    as contract identity (decision of 2026-09-12: the publication number
    is the key for legacy notices)."""
    el = _first(root, "REFERENCE_NUMBER")
    txt = _text(el)
    return txt.strip() if txt and txt.strip() else None


def _modifies_pubnum(root) -> str | None:
    """Publication-number of the notice this modification modifies.

    The legacy ``REF_NOTICE/NO_DOC_OJS`` carries the original notice's OJS
    reference (e.g. ``2017/S 147-305158``); convert it to the machine
    publication-number form (``305158-2017``) so it matches the
    ``modifies_publication_number`` the eForms path gets from the search
    API. Returns None when no reference is published."""
    ref = _first(root, "REF_NOTICE")
    ojs = _text(_first(ref, "NO_DOC_OJS")) if ref is not None else None
    return _ojs_to_pubnum(ojs)


def _ojs_to_pubnum(ojs: str | None) -> str | None:
    """``2017/S 147-305158`` (OJS reference) → ``305158-2017`` (TED
    publication number), the form the graph indexes and back-links use."""
    match = re.match(r"\s*(\d{4})/S\s+\d+-(\d+)", ojs or "")
    return f"{match.group(2)}-{match.group(1)}" if match else None


def _extract_buyer(form, notice_country, organizations) -> str | None:
    """Add the contracting authority to ``organizations`` and return its
    (synthetic) org id, or None when no buyer name is present."""
    block = _first(form, "ADDRESS_CONTRACTING_BODY")
    name = _text(_first(block, "OFFICIALNAME")) if block is not None else None
    if not name:
        return None
    organizations["buyer"] = Organization(
        org_id="buyer",
        name=name,
        country=_country(block, notice_country),
        legal_id=_legal_id(block),
        address=_text(_first(block, "ADDRESS")),
    )
    return "buyer"


def _award_bidder_count(award_contract) -> int | None:
    """The lot's bidder count, published as ``<TENDERS><NB_TENDERS_RECEIVED>``.

    This is the single-bidder signal. Without it every pre-eForms award reads
    as "competition not disclosed" — a statement about this parser, not about
    the buyer. eForms carries the same figure as ReceivedSubmissionsStatistics.
    """
    return _int(_text(_first(award_contract, "NB_TENDERS_RECEIVED")))


def _award_value(award_contract) -> _Money:
    """The award's own total from ``<AWARDED_CONTRACT><VALUES><VAL_TOTAL>``.

    Scoped to this AWARD_CONTRACT so the notice-level OBJECT_CONTRACT total
    cannot leak in. Feeds the loader's "payable" money signal; without it a
    legacy multi-award notice ends up with no value at all (the loader only
    trusts notice.total_value for single-award notices).
    """
    el = _first(award_contract, "VAL_TOTAL")
    if el is None:
        return _Money()
    txt = _text(el)
    return _Money(value=_num(txt), currency=el.get("CURRENCY"), raw=txt)


def _named_contractors(award_contract) -> list[tuple[object, str]]:
    """(address block, name) for each winner that actually names itself."""
    out: list[tuple[object, str]] = []
    for contractor in _local(award_contract, "CONTRACTOR"):
        addr = _first(contractor, "ADDRESS_CONTRACTOR")
        name = _text(
            _first(addr if addr is not None else contractor, "OFFICIALNAME")
        )
        if name:
            out.append((addr, name))
    return out



# ── R2.0.7 / R2.0.8 generation (roughly 2011-2016) ─────────────────────────
# The older XML generation names everything differently: the award block is
# AWARD_OF_CONTRACT (not AWARD_CONTRACT), the bidder count is
# OFFERS_RECEIVED_NUMBER (not NB_TENDERS_RECEIVED), the winner sits in
# ECONOMIC_OPERATOR_NAME_ADDRESS, and the money is VALUE_COST/@FMTVAL under
# CONTRACT_VALUE_INFORMATION. The dialects coexist for years (a 2016 month
# carries more OFFERS_RECEIVED_NUMBER notices than NB_TENDERS_RECEIVED), so
# support is additive, not a cutover by date.


def _oldgen_award_date(award) -> str | None:
    """``<CONTRACT_AWARD_DATE><DAY/><MONTH/><YEAR/>`` -> ISO date."""
    el = _first(award, "CONTRACT_AWARD_DATE")
    if el is None:
        return None
    day, month, year = (
        _text(_first(el, part)) for part in ("DAY", "MONTH", "YEAR")
    )
    if not (day and month and year):
        return None
    try:
        return f"{int(year):04d}-{int(month):02d}-{int(day):02d}"
    except (TypeError, ValueError):
        return None


def _oldgen_award_value(award) -> _Money:
    """The value actually awarded, from CONTRACT_VALUE_INFORMATION.

    Deliberately skips INITIAL_ESTIMATED_TOTAL_VALUE_CONTRACT: that is the
    pre-tender estimate, and booking it as the award would misstate the spend.
    ``@FMTVAL`` carries the machine-readable number (the element text is
    space-grouped, e.g. "1 860 000"); ``raw`` is FMTVAL — the text the value
    is parsed from — which TED normalises to two decimals, so decimal
    presence carries no scale signal in this dialect.
    """
    info = _first(award, "CONTRACT_VALUE_INFORMATION")
    if info is None:
        return _Money()
    for tag in ("COSTS_RANGE_AND_CURRENCY_WITH_VAT_RATE",
                "COSTS_RANGE_AND_CURRENCY"):
        block = _first(info, tag)
        if block is None:
            continue
        cost = _first(block, "VALUE_COST")
        if cost is not None:
            fmtval = cost.get("FMTVAL")
            return _Money(
                value=_num(fmtval), currency=block.get("CURRENCY"), raw=fmtval or None)
    return _Money()


def _extract_awards_oldgen(form, notice_country, organizations) -> list[Award]:
    """Awards in the R2.0.7/R2.0.8 ``AWARD_OF_CONTRACT`` shape."""
    awards: list[Award] = []
    for award in _local(form, "AWARD_OF_CONTRACT"):
        tenders = _int(_text(_first(award, "OFFERS_RECEIVED_NUMBER")))
        money = _oldgen_award_value(award)
        # CONTRACT_AWARD_DATE (V.1, the award decision) has always fed
        # conclusion_date here; its ISO composition is also the only
        # string form the DAY/MONTH/YEAR parts have, so it is the raw too.
        conclusion = _oldgen_award_date(award)
        named = [
            (op, _org_name(op))
            for op in _local(award, "ECONOMIC_OPERATOR_NAME_ADDRESS")
            if _org_name(op)
        ]
        sole_winner = len(named) == 1
        for block, name in named:
            org_id = f"contractor-{len(awards)}"
            organizations[org_id] = Organization(
                org_id=org_id,
                name=name,
                country=_country(block, notice_country),
                legal_id=_legal_id(block),
                address=_text(_first(block, "ADDRESS")),
            )
            awards.append(
                Award(
                    lot_id=org_id,
                    contractor_org_id=org_id,
                    value=money.value if sole_winner else None,
                    currency=money.currency if sole_winner else None,
                    conclusion_date=conclusion,
                    tenders_received=tenders,
                    award_date_raw=conclusion,
                    value_raw=money.raw if sole_winner else None,
                )
            )
    return awards


def _org_name(block) -> str | None:
    """An organisation's name from an address block.

    R2.0.7 writes the name as ORGANISATION's own text; later dialects wrap it
    in OFFICIALNAME. _text() collects descendant text, so ORGANISATION covers
    both — but OFFICIALNAME is tried first because ORGANISATION can also carry
    trailing department lines.
    """
    return _text(_first(block, "OFFICIALNAME")) or _text(_first(block, "ORGANISATION"))


def _extract_buyer_oldgen(form, notice_country, organizations) -> str | None:
    """The contracting authority in the R2.0.7/R2.0.8 dialect.

    It lives in CA_CE_CONCESSIONAIRE_PROFILE, not F03's
    ADDRESS_CONTRACTING_BODY. Without it the loader drops the notice on the
    floor: `buyer = notice.buyer(); if not buyer: return` — which is exactly
    how a month of 12,258 award notices emitted zero events.
    """
    block = _first(form, "CA_CE_CONCESSIONAIRE_PROFILE")
    if block is None:
        block = _first(form, "NAME_ADDRESSES_CONTACT_CONTRACT_AWARD")
    if block is None:
        return None
    name = _org_name(block)
    if not name:
        return None
    organizations["buyer"] = Organization(
        org_id="buyer",
        name=name,
        country=_country(block, notice_country),
        legal_id=_legal_id(block),
        address=_text(_first(block, "ADDRESS")),
    )
    return "buyer"


def _extract_awards(form, notice_country, organizations) -> list[Award]:
    """Add each winning contractor to ``organizations`` and return one
    :class:`Award` per contractor. Org ids are synthetic (legacy notices
    carry none) but stay distinct and internally consistent."""
    awards: list[Award] = []
    for award_contract in _local(form, "AWARD_CONTRACT"):
        lot_no = _text(_first(award_contract, "LOT_NO"))
        conclusion = _fmt_date(
            _text(_first(award_contract, "DATE_CONCLUSION_CONTRACT"))
        )
        tenders = _award_bidder_count(award_contract)
        money = _award_value(award_contract)
        named = _named_contractors(award_contract)
        # A consortium wins ONE contract jointly but lists several CONTRACTORs,
        # and we emit one Award per contractor — attaching the full VAL_TOTAL to
        # each would book money that was never spent. Only a sole winner carries
        # the value; the bidder count is a property of the lot, so every award
        # of this contract legitimately reports it.
        sole_winner = len(named) == 1
        for addr, name in named:
            org_id = f"contractor-{len(awards)}"
            organizations[org_id] = Organization(
                org_id=org_id,
                name=name,
                country=_country(addr, notice_country),
                legal_id=_legal_id(addr),
                address=_text(_first(addr, "ADDRESS")),
            )
            awards.append(
                Award(
                    lot_id=lot_no or org_id,
                    contractor_org_id=org_id,
                    value=money.value if sole_winner else None,
                    currency=money.currency if sole_winner else None,
                    conclusion_date=conclusion,
                    tenders_received=tenders,
                    # The text `value` came from; withheld with it, or a
                    # consortium's shared total would be booked N times.
                    value_raw=money.raw if sole_winner else None,
                )
            )
    # Older notices speak the AWARD_OF_CONTRACT dialect instead. A document
    # only ever uses one of the two, so this is a fallthrough, not a merge.
    if not awards:
        awards = _extract_awards_oldgen(form, notice_country, organizations)
    return awards


def parse_ted_export(root: etree._Element) -> Notice:
    """Parse a legacy ``<TED_EXPORT>`` document into a :class:`Notice`.

    ``notice_id`` is set to the notice's own OJS number (``NO_DOC_OJS``)
    for standalone correctness; the TED loader overrides it with the
    machine publication-number from the search response, since legacy
    notices carry no eForms UUID.
    """
    coded = _first(root, "CODED_DATA_SECTION")
    notice_country = _country(coded, None)
    own_ojs = _text(_first(coded, "NO_DOC_OJS")) or _text(_first(root, "NO_DOC_OJS"))
    # DATE_PUB is the OJS publication date. Legacy TED exports carry no
    # separate buyer issue date, so it populates both fields: consumers
    # asking for publication get the right answer on either ingest path.
    issue_date = _fmt_date(_text(_first(coded, "DATE_PUB")))

    doc_type = _first(root, "TD_DOCUMENT_TYPE")
    notice_type = _DOC_TYPE_TO_NOTICE_TYPE.get(
        doc_type.get("CODE") if doc_type is not None else None
    )

    form = _pick_form(root)
    organizations: dict[str, Organization] = {}
    buyer_org_id = _extract_buyer(form, notice_country, organizations)
    if buyer_org_id is None:
        buyer_org_id = _extract_buyer_oldgen(
            form, notice_country, organizations)
    totals = _modification_values(form)
    awards = _extract_awards(form, notice_country, organizations)

    cpv = _first(form, "CPV_CODE")
    return Notice(
        notice_id=own_ojs or "",
        # Legacy notices have no procedure id: the publication number is
        # their contract identity (decision 2026-09-12).
        publication_number=_ojs_to_pubnum(own_ojs),
        notice_type=notice_type,
        title=_text(_first(form, "TITLE")),
        title_lang=_title_language(form, coded),
        cpv_main=cpv.get("CODE") if cpv is not None else None,
        issue_date=issue_date,
        publication_date=issue_date,
        buyer_org_id=buyer_org_id,
        total_value=totals.after,
        currency=totals.currency,
        total_value_raw=totals.after_raw,
        modification_value_before=totals.before,
        modifies_publication_number=_modifies_pubnum(root),
        legacy_procedure_id=_reference_number(root),
        # LG_ORIG is the two-letter original language ("HU"); eForms'
        # NoticeLanguageCode is three-letter ("HUN"). Verbatim either way.
        notice_language=_text(_first(coded, "LG_ORIG")),
        # No framework fields are set here, on purpose. The S-forms have
        # no framework grouping key at all: OPT-100 and BT-125 are eForms
        # terms with no legacy equivalent, so framework_notice_id stays
        # None on every pre-eForms notice. That is absence of a key, not
        # absence of a framework — a consumer must show nothing rather
        # than "no framework" for these.
        organizations=organizations,
        awards=awards,
    )
